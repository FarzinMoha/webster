import React from 'react'

function Overflow({childre}) {
  return (
    <div className='overflow-x'></div>
  )
}

export default Overflow