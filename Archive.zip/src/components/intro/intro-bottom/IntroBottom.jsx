import React from "react";
import "./IntroBottom.scss";

const IntroBottom = () => {
  return (
    <div className="intro-bottom-animation-container"><h2 className="shine">SHOULD BE UPDATE WITH TECHNOLOGY</h2></div>
  );
};

export default IntroBottom;
